<?php
/** Database Connection Strings */
define("SITE_URL","http://localhost/mojotirenitubiweti/");
define("SITE_URL1","http://localhost");
define("DB_NAME","train2bewealthy"); //iadet910_iadetmobile
define("DB_USER","root");//iadet910_mobile
define("DB_PASSWORD","mysql");//@Kaiste&NstProduct2015
define("DB_SERVER","localhost");
define("__ROOT__",dirname(dirname(__FILE__)));//
define("CLASSES_PATH", __ROOT__.'/classes/');
define("DB_CONFIG_FILE", __ROOT__.'/DbConfig/Database.php');
define("MEDIA_FILES_PATH", '../media/');
define("MEDIA_FILES_PATH1", SITE_URL.'media/');